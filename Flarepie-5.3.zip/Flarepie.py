import tkinter as tk
from tkinter import messagebox, scrolledtext, ttk, filedialog
import matplotlib
matplotlib.use('TkAgg')
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
from matplotlib.figure import Figure
import numpy as np
import csv
import os
from datetime import datetime
from Engine import rocket_simulation, nozzle_performance, get_atmospheric_pressure


def simulate_rocket():
    try:
        fuel_type = fuel_type_entry.get()
        cocp = float(cocp_entry.get())
        ct = float(ct_entry.get())
        altitude = float(altitude_entry.get())
        intmass = float(intmass_entry.get())
        propmass = float(propmass_entry.get())
        mfr = float(mfr_entry.get())
        dt = float(dt_entry.get())

        results = rocket_simulation(
            fuel_type, cocp, ct, altitude, intmass, propmass, mfr, dt
        )

        if "error" in results:
            messagebox.showerror("Error", results["error"])
            return

        result_text.delete(1.0, tk.END)
        result_text.insert(tk.END, "Rocket Simulation Results:\n")
        result_text.insert(tk.END, f"Simulation Time: {results['final_time']:.2f} s\n")
        result_text.insert(tk.END, f"Initial Thrust: {results['initial_thrust']:.2f} N\n")
        result_text.insert(tk.END, f"Total Delta-V: {results['delta_v']:.2f} m/s\n")

        for widget in graph_notebook.winfo_children():
            widget.destroy()

        fig1 = Figure(figsize=(7, 5))

        ax1 = fig1.add_subplot(221)
        ax1.plot(results['time'], results['thrust'], 'b-')
        ax1.set_title('Thrust vs Time')
        ax1.set_xlabel('Time (s)')
        ax1.set_ylabel('Thrust (N)')
        ax1.grid(True)

        ax2 = fig1.add_subplot(222)
        ax2.plot(results['time'], results['fuel_remaining'], 'g-')
        ax2.set_title('Fuel Remaining vs Time')
        ax2.set_xlabel('Time (s)')
        ax2.set_ylabel('Remaining Propellant (kg)')
        ax2.grid(True)

        ax3 = fig1.add_subplot(223)
        ax3.plot(results['time'], results['mass_flow'], 'r-')
        ax3.set_title('Mass Flow Rate vs Time')
        ax3.set_xlabel('Time (s)')
        ax3.set_ylabel('Mass Flow (kg/s)')
        ax3.grid(True)

        ax4 = fig1.add_subplot(224)
        ax4.plot(results['time'], results['velocity'], 'm-')
        ax4.set_title('Velocity vs Time')
        ax4.set_xlabel('Time (s)')
        ax4.set_ylabel('Velocity (m/s)')
        ax4.grid(True)

        fig1.tight_layout()
        canvas1 = FigureCanvasTkAgg(fig1, master=graph_notebook)
        canvas1.draw()
        canvas1.get_tk_widget().pack(fill=tk.BOTH, expand=True)

        fig2 = Figure(figsize=(7, 5))

        ax1 = fig2.add_subplot(221)
        ax1.plot(results['time'], results['altitude'], 'k-')
        ax1.set_title('Altitude vs Time')
        ax1.set_xlabel('Time (s)')
        ax1.set_ylabel('Altitude (m)')
        ax1.grid(True)

        ax2 = fig2.add_subplot(222)
        ax2.plot(results['time'], results['isp_values'], 'c-')
        ax2.set_title('Specific Impulse vs Time')
        ax2.set_xlabel('Time (s)')
        ax2.set_ylabel('Isp (s)')
        ax2.grid(True)

        ax3 = fig2.add_subplot(223)
        ax3.plot(results['time'], [get_atmospheric_pressure(h) for h in results['altitude']], 'y-')
        ax3.set_title('Atmospheric Pressure vs Time')
        ax3.set_xlabel('Time (s)')
        ax3.set_ylabel('Pressure (Pa)')
        ax3.grid(True)

        ax4 = fig2.add_subplot(224)
        tw_ratio = [thrust / 9.81 for thrust in results['thrust']]
        ax4.plot(results['time'], tw_ratio, 'y-')
        ax4.set_title('Thrust-to-Weight Ratio vs Time')
        ax4.set_xlabel('Time (s)')
        ax4.set_ylabel('T/W Ratio')
        ax4.grid(True)

        fig2.tight_layout()
        canvas2 = FigureCanvasTkAgg(fig2, master=graph_notebook)
        canvas2.draw()
        canvas2.get_tk_widget().pack(fill=tk.BOTH, expand=True)

        if save_to_file_var.get():
            save_rocket_results_to_file(results)

    except ValueError as e:
        messagebox.showerror("Input Error", f"Please enter valid numeric values: {str(e)}")


def save_rocket_results_to_file(results):
    try:
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        filename = f"rocket_simulation_results_{timestamp}.csv"

        with open(filename, mode='w', newline='', encoding='utf-8') as csvfile:
            fieldnames = [
                'time', 'thrust', 'fuel_remaining', 'mass_flow',
                'velocity', 'altitude', 'isp', 'delta_v'
            ]
            writer = csv.DictWriter(csvfile, fieldnames=fieldnames)
            writer.writeheader()

            for t, thr, fr, mf, vel, alt, isp in zip(
                    results['time'],
                    results['thrust'],
                    results['fuel_remaining'],
                    results['mass_flow'],
                    results['velocity'],
                    results['altitude'],
                    results['isp_values']):
                writer.writerow({
                    'time': t,
                    'thrust': thr,
                    'fuel_remaining': fr,
                    'mass_flow': mf,
                    'velocity': vel,
                    'altitude': alt,
                    'isp': isp,
                    'delta_v': results['delta_v']
                })

        messagebox.showinfo("File Saved", f"Results saved to {filename}")
    except Exception as e:
        messagebox.showerror("File Error", f"Could not save file: {str(e)}")


def simulate_nozzle():
    try:
        mfr = float(mfr_nozzle_entry.get())
        ve = float(ve_entry.get())
        expa = float(expa_entry.get())
        amp = float(amp_entry.get())
        ea = float(ea_entry.get())

        results = nozzle_performance(mfr, ve, expa, amp, ea)

        result_text.delete(1.0, tk.END)
        result_text.insert(tk.END, "Nozzle Performance Results:\n")
        result_text.insert(tk.END, f"Total Thrust: {results['thrust']:.2f} N\n")
        result_text.insert(tk.END, f"Specific Impulse: {results['isp']:.2f} s\n")
        result_text.insert(tk.END, f"Pressure Thrust: {results['pressure_thrust']:.2f} N\n")
        result_text.insert(tk.END, f"Momentum Thrust: {results['momentum_thrust']:.2f} N\n")

        for widget in graph_notebook.winfo_children():
            widget.destroy()

        fig = Figure(figsize=(8, 4))

        ax1 = fig.add_subplot(121)
        components = ['Total Thrust', 'Pressure Thrust', 'Momentum Thrust']
        values = [results['thrust'], results['pressure_thrust'], results['momentum_thrust']]
        ax1.bar(components, values)
        ax1.set_title('Thrust Components')
        ax1.set_ylabel('Thrust (N)')
        for tick in ax1.get_xticklabels():
            tick.set_rotation(45)

        ax2 = fig.add_subplot(122)
        ax2.bar(['Specific Impulse'], [results['isp']])
        ax2.set_title('Specific Impulse')
        ax2.set_ylabel('Isp (s)')

        fig.tight_layout()
        canvas = FigureCanvasTkAgg(fig, master=graph_notebook)
        canvas.draw()
        canvas.get_tk_widget().pack(fill=tk.BOTH, expand=True)

        if save_to_file_var.get():
            save_nozzle_results_to_file(results)

    except ValueError as e:
        messagebox.showerror("Input Error", f"Please enter valid numeric values: {str(e)}")


def save_nozzle_results_to_file(results):
    try:
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        filename = f"nozzle_performance_results_{timestamp}.csv"

        with open(filename, mode='w', newline='', encoding='utf-8') as csvfile:
            fieldnames = ['thrust', 'isp', 'pressure_thrust', 'momentum_thrust']
            writer = csv.DictWriter(csvfile, fieldnames=fieldnames)
            writer.writeheader()
            writer.writerow(results)

        messagebox.showinfo("File Saved", f"Results saved to {filename}")
    except Exception as e:
        messagebox.showerror("File Error", f"Could not save file: {str(e)}")


if __name__ == "__main__":
    root = tk.Tk()
    root.title("FlarePie - Rocket Engine Simulator (with Delta-V & Dynamic Pressure)")

    main_frame = ttk.Frame(root)
    main_frame.pack(fill=tk.BOTH, expand=True)

    input_frame = ttk.Frame(main_frame)
    input_frame.pack(side=tk.LEFT, padx=10, pady=10, fill=tk.Y)

    right_frame = ttk.Frame(main_frame)
    right_frame.pack(side=tk.RIGHT, padx=10, pady=10, fill=tk.BOTH, expand=True)

    graph_notebook = ttk.Notebook(right_frame)
    graph_notebook.pack(fill=tk.BOTH, expand=True)

    input_fields = [
        ("Fuel Type (RP1, LH2, SRF, N2O4):", "fuel_type_entry"),
        ("Combustion Chamber Pressure (Pa):", "cocp_entry"),
        ("Combustion Temperature (K):", "ct_entry"),
        ("Initial Altitude (m):", "altitude_entry"),
        ("Total Mass, including Propellant (Kg):", "intmass_entry"),
        ("Propellant Mass (Kg):", "propmass_entry"),
        ("Mass Flow Rate (Kg/s):", "mfr_entry"),
        ("Simulation Timestep (s):", "dt_entry")
    ]

    for i, (label, var_name) in enumerate(input_fields):
        ttk.Label(input_frame, text=label).grid(row=i, column=0, sticky='w', padx=5, pady=2)
        entry = ttk.Entry(input_frame)
        entry.grid(row=i, column=1, padx=5, pady=2)
        globals()[var_name] = entry

    ttk.Button(input_frame, text="Run Rocket Simulation",
               command=simulate_rocket).grid(row=len(input_fields), column=0, columnspan=2, pady=10)

    nozzle_fields = [
        ("Mass Flow Rate (Kg/s):", "mfr_nozzle_entry"),
        ("Exhaust Velocity (m/s):", "ve_entry"),
        ("Exit Pressure (Pa):", "expa_entry"),
        ("Ambient Pressure (Pa):", "amp_entry"),
        ("Exit Area (m^2):", "ea_entry")
    ]

    start_row = len(input_fields) + 1
    for i, (label, var_name) in enumerate(nozzle_fields):
        ttk.Label(input_frame, text=label).grid(row=start_row + i, column=0, sticky='w', padx=5, pady=2)
        entry = ttk.Entry(input_frame)
        entry.grid(row=start_row + i, column=1, padx=5, pady=2)
        globals()[var_name] = entry

    ttk.Button(input_frame, text="Run Nozzle Performance",
               command=simulate_nozzle).grid(row=start_row + len(nozzle_fields),
                                             column=0, columnspan=2, pady=10)

    save_to_file_var = tk.IntVar()
    save_checkbox = ttk.Checkbutton(input_frame, text="Save Results to File", variable=save_to_file_var)
    save_checkbox.grid(row=start_row + len(nozzle_fields) + 1, column=0, columnspan=2, pady=5)

    result_frame = ttk.Frame(right_frame)
    result_frame.pack(fill=tk.BOTH, expand=True)

    ttk.Label(result_frame, text="Results:").pack()
    result_text = scrolledtext.ScrolledText(result_frame, width=50, height=10)
    result_text.pack(fill=tk.BOTH, expand=True)

    root.mainloop()