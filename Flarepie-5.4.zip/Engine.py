import math


def get_atmospheric_pressure(altitude):
    if altitude < 0:
        altitude = 0
    p0 = 101325.0
    lapse_rate = 2.25577e-5
    exponent = 5.25588
    pressure = p0 * (1 - lapse_rate * altitude) ** exponent
    if pressure < 0:
        pressure = 0
    return pressure


def rocket_simulation(fuel_type, cocp, ct, altitude, intmass, propmass, mfr, dt):
    if fuel_type == "RP1":
        k = 1.2
        R = 287.0
    elif fuel_type == "LH2":
        k = 1.4
        R = 4124.0
    elif fuel_type == "SRF":
        k = 1.2
        R = 191.0
    elif fuel_type == "N2O4":
        k = 1.26
        R = 320.0
    else:
        return {"error": "Invalid fuel type"}

    current_mass = intmass
    time_elapsed = 0.0
    velocity = 0.0
    current_altitude = altitude
    delta_v = 0.0

    time_steps = []
    thrust_values = []
    fuel_remaining = []
    mass_flow_values = []
    velocity_values = []
    altitude_values = []
    isp_values = []

    while propmass > 0:
        ap = get_atmospheric_pressure(current_altitude)

        try:
            pressure_ratio = (ap / cocp) ** ((k - 1) / k)
        except ValueError:
            pressure_ratio = 0.0

        ve = math.sqrt((2.0 * k) / (k - 1.0) * R * ct * (1.0 - pressure_ratio))

        thrust = mfr * ve
        mass_used = mfr * dt
        if mass_used > propmass:
            mass_used = propmass

        propmass -= mass_used
        current_mass -= mass_used

        acceleration = (thrust / current_mass) - 9.81
        velocity_new = velocity + acceleration * dt
        delta_v_step = max(0.0, (velocity_new - velocity))
        delta_v += delta_v_step

        altitude_new = current_altitude + velocity * dt

        time_steps.append(time_elapsed)
        thrust_values.append(thrust)
        fuel_remaining.append(propmass)
        mass_flow_values.append(mfr)
        velocity_values.append(velocity)
        altitude_values.append(current_altitude)

        isp = thrust / (mfr * 9.81) if mfr > 0 else 0.0
        isp_values.append(isp)

        velocity = velocity_new
        current_altitude = altitude_new
        time_elapsed += dt

    return {
        "time": time_steps,
        "thrust": thrust_values,
        "fuel_remaining": fuel_remaining,
        "mass_flow": mass_flow_values,
        "velocity": velocity_values,
        "altitude": altitude_values,
        "isp_values": isp_values,
        "final_time": time_elapsed,
        "initial_thrust": thrust_values[0] if thrust_values else 0,
        "delta_v": delta_v
    }


def nozzle_performance(mfr, ve, expa, amp, ea):
    thrust = (mfr * ve) + ((expa - amp) * ea)
    isp = thrust / (mfr * 9.81) if mfr > 0 else 0.0

    return {
        "thrust": thrust,
        "isp": isp,
        "pressure_thrust": (expa - amp) * ea,
        "momentum_thrust": mfr * ve
    }