import tkinter as tk
from tkinter import messagebox, scrolledtext, ttk
import matplotlib
matplotlib.use('TkAgg')
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
from matplotlib.figure import Figure
import numpy as np
import csv
from datetime import datetime
from Engine import rocket_simulation, nozzle_performance, get_atmospheric_pressure

def simulate_rocket():
    try:
        fuel_type = fuel_type_entry.get()
        cocp = float(cocp_entry.get())
        ct = float(ct_entry.get())
        altitude = float(altitude_entry.get())
        intmass = float(intmass_entry.get())
        propmass = float(propmass_entry.get())
        mfr = float(mfr_entry.get())
        dt = float(dt_entry.get())

        results = rocket_simulation(
            fuel_type, cocp, ct, altitude, intmass, propmass, mfr, dt
        )

        if "error" in results:
            messagebox.showerror("Error", results["error"])
            return

        result_text.delete(1.0, tk.END)
        result_text.insert(tk.END, "Rocket Simulation Results:\n")
        result_text.insert(tk.END, f"Simulation Time: {results['final_time']:.2f} s\n")
        result_text.insert(tk.END, f"Initial Thrust: {results['initial_thrust']:.2f} N\n")
        result_text.insert(tk.END, f"Total Delta-V: {results['delta_v']:.2f} m/s\n\n")

        result_text.insert(tk.END, "Second-by-Second Data:\n")
        for i, t in enumerate(results['time']):
            result_text.insert(
                tk.END,
                f"t={t:.2f}s | Thrust={results['thrust'][i]:.2f} N | "
                f"MassFlow={results['mass_flow'][i]:.3f} kg/s | FuelRem={results['fuel_remaining'][i]:.2f} kg | "
                f"Velocity={results['velocity'][i]:.2f} m/s | Alt={results['altitude'][i]:.2f} m | "
                f"Isp={results['isp_values'][i]:.2f} s\n"
            )

        for widget in graph_notebook.winfo_children():
            widget.destroy()

        fig1 = Figure(figsize=(5, 3), facecolor="#232931")
        ax1 = fig1.add_subplot(221, facecolor="#232931")
        ax1.plot(results['time'], results['thrust'], color="white", linewidth=1.2)
        ax1.set_title('Thrust vs Time', color="white", fontweight='bold')
        ax1.set_xlabel('Time (s)', color="white")
        ax1.set_ylabel('Thrust (N)', color="white")
        ax1.grid(True, linestyle='--', alpha=0.4)
        _darken_axes(ax1)

        ax2 = fig1.add_subplot(222, facecolor="#232931")
        ax2.plot(results['time'], results['fuel_remaining'], color="red", linewidth=1.2)
        ax2.set_title('Fuel Remaining', color="white", fontweight='bold')
        ax2.set_xlabel('Time (s)', color="white")
        ax2.set_ylabel('Propellant (kg)', color="white")
        ax2.grid(True, linestyle='--', alpha=0.4)
        _darken_axes(ax2)

        ax3 = fig1.add_subplot(223, facecolor="#232931")
        ax3.plot(results['time'], results['mass_flow'], color="orange", linewidth=1.2)
        ax3.set_title('Mass Flow', color="white", fontweight='bold')
        ax3.set_xlabel('Time (s)', color="white")
        ax3.set_ylabel('Mass Flow (kg/s)', color="white")
        ax3.grid(True, linestyle='--', alpha=0.4)
        _darken_axes(ax3)

        ax4 = fig1.add_subplot(224, facecolor="#232931")
        ax4.plot(results['time'], results['velocity'], color="cyan", linewidth=1.2)
        ax4.set_title('Velocity vs Time', color="white", fontweight='bold')
        ax4.set_xlabel('Time (s)', color="white")
        ax4.set_ylabel('Velocity (m/s)', color="white")
        ax4.grid(True, linestyle='--', alpha=0.4)
        _darken_axes(ax4)

        fig1.suptitle("Rocket Performance Charts", color="white", fontweight='bold')
        fig1.tight_layout()
        canvas1 = FigureCanvasTkAgg(fig1, master=graph_notebook)
        canvas1.draw()
        canvas1.get_tk_widget().pack(fill=tk.BOTH, expand=True)

        fig2 = Figure(figsize=(5, 3), facecolor="#232931")

        ax1_2 = fig2.add_subplot(221, facecolor="#232931")
        ax1_2.plot(results['time'], results['altitude'], color="white", linewidth=1.2)
        ax1_2.set_title('Altitude vs Time', color="white", fontweight='bold')
        ax1_2.set_xlabel('Time (s)', color="white")
        ax1_2.set_ylabel('Altitude (m)', color="white")
        ax1_2.grid(True, linestyle='--', alpha=0.4)
        _darken_axes(ax1_2)

        ax2_2 = fig2.add_subplot(222, facecolor="#232931")
        ax2_2.plot(results['time'], results['isp_values'], color="red", linewidth=1.2)
        ax2_2.set_title('Specific Impulse', color="white", fontweight='bold')
        ax2_2.set_xlabel('Time (s)', color="white")
        ax2_2.set_ylabel('Isp (s)', color="white")
        ax2_2.grid(True, linestyle='--', alpha=0.4)
        _darken_axes(ax2_2)

        ax3_2 = fig2.add_subplot(223, facecolor="#232931")
        ax3_2.plot(
            results['time'],
            [get_atmospheric_pressure(h) for h in results['altitude']],
            color="orange",
            linewidth=1.2
        )
        ax3_2.set_title('Atmospheric Pressure', color="white", fontweight='bold')
        ax3_2.set_xlabel('Time (s)', color="white")
        ax3_2.set_ylabel('Pressure (Pa)', color="white")
        ax3_2.grid(True, linestyle='--', alpha=0.4)
        _darken_axes(ax3_2)

        ax4_2 = fig2.add_subplot(224, facecolor="#232931")
        tw_ratio = [thr / 9.81 for thr in results['thrust']]
        ax4_2.plot(results['time'], tw_ratio, color="cyan", linewidth=1.2)
        ax4_2.set_title('Thrust/Weight Ratio', color="white", fontweight='bold')
        ax4_2.set_xlabel('Time (s)', color="white")
        ax4_2.set_ylabel('T/W', color="white")
        ax4_2.grid(True, linestyle='--', alpha=0.4)
        _darken_axes(ax4_2)

        fig2.suptitle("Flight Conditions & Performance", color="white", fontweight='bold')
        fig2.tight_layout()
        canvas2 = FigureCanvasTkAgg(fig2, master=graph_notebook)
        canvas2.draw()
        canvas2.get_tk_widget().pack(fill=tk.BOTH, expand=True)

        if save_to_file_var.get():
            save_rocket_results_to_file(results)

    except ValueError as e:
        messagebox.showerror("Input Error", f"Please enter valid numeric values: {str(e)}")


def save_rocket_results_to_file(results):
    try:
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        filename = f"rocket_simulation_results_{timestamp}.csv"
        with open(filename, mode='w', newline='', encoding='utf-8') as csvfile:
            fieldnames = [
                'time', 'thrust', 'fuel_remaining', 'mass_flow',
                'velocity', 'altitude', 'isp', 'delta_v'
            ]
            writer = csv.DictWriter(csvfile, fieldnames=fieldnames)
            writer.writeheader()

            for t, thr, fr, mf, vel, alt, isp in zip(
                results['time'],
                results['thrust'],
                results['fuel_remaining'],
                results['mass_flow'],
                results['velocity'],
                results['altitude'],
                results['isp_values']
            ):
                writer.writerow({
                    'time': t,
                    'thrust': thr,
                    'fuel_remaining': fr,
                    'mass_flow': mf,
                    'velocity': vel,
                    'altitude': alt,
                    'isp': isp,
                    'delta_v': results['delta_v']
                })

        messagebox.showinfo("File Saved", f"Results saved to {filename}")
    except Exception as e:
        messagebox.showerror("File Error", f"Could not save file: {str(e)}")


def simulate_nozzle():
    try:
        mfr = float(mfr_nozzle_entry.get())
        ve = float(ve_entry.get())
        expa = float(expa_entry.get())
        amp = float(amp_entry.get())
        ea = float(ea_entry.get())

        results = nozzle_performance(mfr, ve, expa, amp, ea)

        result_text.delete(1.0, tk.END)
        result_text.insert(tk.END, "Nozzle Performance Results:\n")
        result_text.insert(tk.END, f"Total Thrust: {results['thrust']:.2f} N\n")
        result_text.insert(tk.END, f"Specific Impulse: {results['isp']:.2f} s\n")
        result_text.insert(tk.END, f"Pressure Thrust: {results['pressure_thrust']:.2f} N\n")
        result_text.insert(tk.END, f"Momentum Thrust: {results['momentum_thrust']:.2f} N\n")

        for widget in graph_notebook.winfo_children():
            widget.destroy()

        fig = Figure(figsize=(5, 3), facecolor="#232931")
        ax1 = fig.add_subplot(121, facecolor="#232931")
        components = ['Total', 'Pressure', 'Momentum']
        values = [results['thrust'], results['pressure_thrust'], results['momentum_thrust']]
        ax1.bar(components, values, color=['white', 'red', 'cyan'], width=0.5)
        ax1.set_title('Thrust Components', color="white", fontweight='bold')
        ax1.set_ylabel('Thrust (N)', color="white")
        ax1.grid(True, linestyle='--', alpha=0.4)
        _darken_axes(ax1, bar_chart=True)

        ax2 = fig.add_subplot(122, facecolor="#232931")
        ax2.bar(['Isp'], [results['isp']], color='red', width=0.5)
        ax2.set_title('Specific Impulse', color="white", fontweight='bold')
        ax2.set_ylabel('Isp (s)', color="white")
        ax2.grid(True, linestyle='--', alpha=0.4)
        _darken_axes(ax2, bar_chart=True)

        fig.suptitle("Nozzle Performance", color="white", fontweight='bold')
        fig.tight_layout()
        canvas = FigureCanvasTkAgg(fig, master=graph_notebook)
        canvas.draw()
        canvas.get_tk_widget().pack(fill=tk.BOTH, expand=True)

        if save_to_file_var.get():
            save_nozzle_results_to_file(results)

    except ValueError as e:
        messagebox.showerror("Input Error", f"Please enter valid numeric values: {str(e)}")


def save_nozzle_results_to_file(results):
    try:
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        filename = f"nozzle_performance_results_{timestamp}.csv"
        with open(filename, mode='w', newline='', encoding='utf-8') as csvfile:
            fieldnames = ['thrust', 'isp', 'pressure_thrust', 'momentum_thrust']
            writer = csv.DictWriter(csvfile, fieldnames=fieldnames)
            writer.writeheader()
            writer.writerow(results)

        messagebox.showinfo("File Saved", f"Results saved to {filename}")
    except Exception as e:
        messagebox.showerror("File Error", f"Could not save file: {str(e)}")


def _darken_axes(ax, bar_chart=False):
    ax.tick_params(axis='x', colors='white', labelsize=8)
    ax.tick_params(axis='y', colors='white', labelsize=8)
    for spine in ax.spines.values():
        spine.set_color('white')
    if bar_chart:
        for label in ax.get_xticklabels():
            label.set_color('white')


def create_custom_style():
    style = ttk.Style()
    style.theme_use('clam')

    style.configure("TFrame", background="#0D1B2A")

    style.configure(
        "TLabel",
        font=("Helvetica", 10, "bold"),
        foreground="#E0E1DD",
        background="#0D1B2A"
    )

    style.configure(
        "TButton",
        font=("Helvetica", 10, "bold"),
        foreground="#E0E1DD",
        background="#1B263B",
        padding=6
    )
    style.map("TButton", background=[('active', '#415A77')])

    style.configure(
        "TCheckbutton",
        font=("Helvetica", 10),
        foreground="#E0E1DD",
        background="#0D1B2A"
    )

    style.configure(
        "TNotebook",
        background="#1B263B",
        tabmargins=[10, 10, 10, 0]
    )
    style.configure(
        "TNotebook.Tab",
        font=("Helvetica", 10, "bold"),
        foreground="#E0E1DD",
        padding=[10, 5]
    )
    style.map("TNotebook.Tab", background=[("selected", "#415A77"), ("active", "#778DA9")])

    style.configure("Vertical.TScrollbar", background="#1B263B")

    return style


if __name__ == "__main__":
    root = tk.Tk()
    root.title("FlarePie - Rocket Engine Simulator (Time Step Display)")

    custom_style = create_custom_style()

    main_frame = ttk.Frame(root, style="TFrame")
    main_frame.pack(fill=tk.BOTH, expand=True)

    input_frame = ttk.Frame(main_frame, style="TFrame")
    input_frame.pack(side=tk.LEFT, padx=10, pady=10, fill=tk.Y)

    right_frame = ttk.Frame(main_frame, style="TFrame")
    right_frame.pack(side=tk.RIGHT, padx=10, pady=10, fill=tk.BOTH, expand=True)

    graph_notebook = ttk.Notebook(right_frame, style="TNotebook")
    graph_notebook.pack(fill=tk.BOTH, expand=True)

    input_fields = [
        ("Fuel Type (RP1, LH2, SRF, N2O4):", "fuel_type_entry"),
        ("Combustion Chamber Pressure (Pa):", "cocp_entry"),
        ("Combustion Temperature (K):", "ct_entry"),
        ("Initial Altitude (m):", "altitude_entry"),
        ("Total Mass incl. Propellant (Kg):", "intmass_entry"),
        ("Propellant Mass (Kg):", "propmass_entry"),
        ("Mass Flow Rate (Kg/s):", "mfr_entry"),
        ("Simulation Timestep (s [>5]):", "dt_entry")
    ]

    for i, (label, var_name) in enumerate(input_fields):
        ttk.Label(input_frame, text=label, style="TLabel").grid(row=i, column=0, sticky='w', padx=5, pady=2)
        entry = ttk.Entry(input_frame, font=("Helvetica", 10))
        entry.grid(row=i, column=1, padx=5, pady=2)
        globals()[var_name] = entry

    ttk.Button(
        input_frame,
        text="Run Rocket Simulation",
        command=simulate_rocket,
        style="TButton"
    ).grid(row=len(input_fields), column=0, columnspan=2, pady=10)

    nozzle_fields = [
        ("Mass Flow Rate (Kg/s):", "mfr_nozzle_entry"),
        ("Exhaust Velocity (m/s):", "ve_entry"),
        ("Exit Pressure (Pa):", "expa_entry"),
        ("Ambient Pressure (Pa):", "amp_entry"),
        ("Exit Area (m^2):", "ea_entry")
    ]

    start_row = len(input_fields) + 1
    for i, (label, var_name) in enumerate(nozzle_fields):
        ttk.Label(input_frame, text=label, style="TLabel").grid(row=start_row + i, column=0, sticky='w', padx=5, pady=2)
        entry = ttk.Entry(input_frame, font=("Helvetica", 10))
        entry.grid(row=start_row + i, column=1, padx=5, pady=2)
        globals()[var_name] = entry

    ttk.Button(
        input_frame,
        text="Run Nozzle Performance",
        command=simulate_nozzle,
        style="TButton"
    ).grid(row=start_row + len(nozzle_fields), column=0, columnspan=2, pady=10)

    save_to_file_var = tk.IntVar()
    save_checkbox = ttk.Checkbutton(
        input_frame,
        text="Save Results to File",
        variable=save_to_file_var,
        style="TCheckbutton"
    )
    save_checkbox.grid(row=start_row + len(nozzle_fields) + 1, column=0, columnspan=2, pady=5)

    result_frame = ttk.Frame(right_frame, style="TFrame")
    result_frame.pack(fill=tk.BOTH, expand=True)

    ttk.Label(result_frame, text="Results:", style="TLabel").pack(anchor='nw', padx=5, pady=5)
    result_text = scrolledtext.ScrolledText(result_frame, width=60, height=10, font=("Courier", 10))
    result_text.pack(fill=tk.BOTH, expand=True, padx=5, pady=5)

    root.minsize(900, 500)
    root.mainloop()