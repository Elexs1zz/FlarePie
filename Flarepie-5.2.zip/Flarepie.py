import tkinter as tk
from tkinter import messagebox, scrolledtext, ttk
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
from matplotlib.figure import Figure
import numpy as np
from Engine import rocket_simulation, nozzle_performance


def create_graph_frame():
    return ttk.Notebook(root)


def simulate_rocket():
    try:
        fuel_type = fuel_type_entry.get()
        cocp = float(cocp_entry.get())
        ct = float(ct_entry.get())
        ap = float(ap_entry.get())
        intmass = float(intmass_entry.get())
        propmass = float(propmass_entry.get())
        mfr = float(mfr_entry.get())
        dt = float(dt_entry.get())

        results = rocket_simulation(fuel_type, cocp, ct, ap, intmass, propmass, mfr, dt)

        if "error" in results:
            messagebox.showerror("Error", results["error"])
            return

        result_text.delete(1.0, tk.END)
        result_text.insert(tk.END, "Rocket Simulation Results:\n")
        result_text.insert(tk.END, f"Simulation time: {results['final_time']:.2f} seconds\n")
        result_text.insert(tk.END, f"Initial thrust: {results['initial_thrust']:.2f} N\n")

        for widget in graph_notebook.winfo_children():
            widget.destroy()

        fig = Figure(figsize=(12, 8))

        ax1 = fig.add_subplot(221)
        ax1.plot(results['time'], results['thrust'], 'b-')
        ax1.set_title('Thrust vs Time')
        ax1.set_xlabel('Time (s)')
        ax1.set_ylabel('Thrust (N)')
        ax1.grid(True)

        ax2 = fig.add_subplot(222)
        ax2.plot(results['time'], results['fuel_remaining'], 'g-')
        ax2.set_title('Fuel Remaining vs Time')
        ax2.set_xlabel('Time (s)')
        ax2.set_ylabel('Fuel Mass (kg)')
        ax2.grid(True)

        ax3 = fig.add_subplot(223)
        ax3.plot(results['time'], results['mass_flow'], 'r-')
        ax3.set_title('Mass Flow Rate vs Time')
        ax3.set_xlabel('Time (s)')
        ax3.set_ylabel('Mass Flow Rate (kg/s)')
        ax3.grid(True)

        ax4 = fig.add_subplot(224)
        ax4.plot(results['time'], results['velocity'], 'm-')
        ax4.set_title('Exhaust Velocity vs Time')
        ax4.set_xlabel('Time (s)')
        ax4.set_ylabel('Velocity (m/s)')
        ax4.grid(True)

        fig.tight_layout()
        canvas = FigureCanvasTkAgg(fig, master=graph_notebook)
        canvas.draw()
        canvas.get_tk_widget().pack(fill=tk.BOTH, expand=True)

        fig = Figure(figsize=(12, 8))

        ax1 = fig.add_subplot(321)
        ax2 = fig.add_subplot(322)
        ax3 = fig.add_subplot(323)
        ax4 = fig.add_subplot(324)

        ax5 = fig.add_subplot(325)
        ax5.plot(results['time'], [thrust / 9.81 for thrust in results['thrust']], 'y-')
        ax5.set_title('Thrust-to-Weight Ratio vs Time')
        ax5.set_xlabel('Time (s)')
        ax5.set_ylabel('T/W Ratio')
        ax5.grid(True)

        ax6 = fig.add_subplot(326)
        ax6.plot(results['time'],
                 [thrust / (mfr * 9.81) for thrust, mfr in zip(results['thrust'], results['mass_flow'])],
                 'c-')
        ax6.set_title('Specific Impulse vs Time')
        ax6.set_xlabel('Time (s)')
        ax6.set_ylabel('Isp (s)')
        ax6.grid(True)

    except ValueError as e:
        messagebox.showerror("Input Error", f"Please enter valid numeric values: {str(e)}")


def simulate_nozzle():
    try:

        mfr = float(mfr_nozzle_entry.get())
        ve = float(ve_entry.get())
        expa = float(expa_entry.get())
        amp = float(amp_entry.get())
        ea = float(ea_entry.get())

        results = nozzle_performance(mfr, ve, expa, amp, ea)

        result_text.delete(1.0, tk.END)
        result_text.insert(tk.END, "Nozzle Performance Results:\n")
        result_text.insert(tk.END, f"Total Thrust: {results['thrust']:.2f} N\n")
        result_text.insert(tk.END, f"Specific Impulse: {results['isp']:.2f} s\n")
        result_text.insert(tk.END, f"Pressure Thrust: {results['pressure_thrust']:.2f} N\n")
        result_text.insert(tk.END, f"Momentum Thrust: {results['momentum_thrust']:.2f} N\n")

        fig = Figure(figsize=(8, 6))
        ax = fig.add_subplot(111)

        components = ['Total Thrust', 'Pressure Thrust', 'Momentum Thrust']
        values = [results['thrust'], results['pressure_thrust'], results['momentum_thrust']]

        ax.bar(components, values)
        ax.set_title('Thrust Components')
        ax.set_ylabel('Thrust (N)')
        plt.xticks(rotation=45)

        fig.tight_layout()

        for widget in graph_notebook.winfo_children():
            widget.destroy()

        canvas = FigureCanvasTkAgg(fig, master=graph_notebook)
        canvas.draw()
        canvas.get_tk_widget().pack(fill=tk.BOTH, expand=True)

    except ValueError as e:
        messagebox.showerror("Input Error", f"Please enter valid numeric values: {str(e)}")


root = tk.Tk()
root.title("FlarePie - Rocket Engine Simulator")

main_frame = ttk.Frame(root)
main_frame.pack(fill=tk.BOTH, expand=True)

input_frame = ttk.Frame(main_frame)
input_frame.pack(side=tk.LEFT, padx=10, pady=10, fill=tk.Y)

right_frame = ttk.Frame(main_frame)
right_frame.pack(side=tk.RIGHT, padx=10, pady=10, fill=tk.BOTH, expand=True)

graph_notebook = ttk.Notebook(right_frame)
graph_notebook.pack(fill=tk.BOTH, expand=True)

input_fields = [
    ("Fuel Type (RP1, LH2, SRF, N2O4):", "fuel_type_entry"),
    ("Combustion Chamber Pressure (Pa):", "cocp_entry"),
    ("Combustion Temperature (K):", "ct_entry"),
    ("Atmospheric Pressure (Pa):", "ap_entry"),
    ("Total Mass, including Propellant (Kg):", "intmass_entry"),
    ("Propellant Mass (Kg):", "propmass_entry"),
    ("Mass Flow Rate (Kg/s):", "mfr_entry"),
    ("Simulation Timestep (s):", "dt_entry")
]

for i, (label, var_name) in enumerate(input_fields):
    ttk.Label(input_frame, text=label).grid(row=i, column=0, sticky='w', padx=5, pady=2)
    entry = ttk.Entry(input_frame)
    entry.grid(row=i, column=1, padx=5, pady=2)
    globals()[var_name] = entry

ttk.Button(input_frame, text="Run Rocket Simulation",
           command=simulate_rocket).grid(row=len(input_fields), column=0, columnspan=2, pady=10)

nozzle_fields = [
    ("Mass Flow Rate (Kg/s):", "mfr_nozzle_entry"),
    ("Exhaust Velocity (m/s):", "ve_entry"),
    ("Exit Pressure (Pa):", "expa_entry"),
    ("Ambient Pressure (Pa):", "amp_entry"),
    ("Exit Area (m^2):", "ea_entry")
]

start_row = len(input_fields) + 1
for i, (label, var_name) in enumerate(nozzle_fields):
    ttk.Label(input_frame, text=label).grid(row=start_row + i, column=0, sticky='w', padx=5, pady=2)
    entry = ttk.Entry(input_frame)
    entry.grid(row=start_row + i, column=1, padx=5, pady=2)
    globals()[var_name] = entry

ttk.Button(input_frame, text="Run Nozzle Performance",
           command=simulate_nozzle).grid(row=start_row + len(nozzle_fields),
                                         column=0, columnspan=2, pady=10)

result_frame = ttk.Frame(right_frame)
result_frame.pack(fill=tk.BOTH, expand=True)

ttk.Label(result_frame, text="Results:").pack()
result_text = scrolledtext.ScrolledText(result_frame, width=50, height=10)
result_text.pack(fill=tk.BOTH, expand=True)

root.mainloop()