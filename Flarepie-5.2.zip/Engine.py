import math
import matplotlib.pyplot as plt
import numpy as np


def rocket_simulation(fuel_type, cocp, ct, ap, intmass, propmass, mfr, dt):
    if fuel_type == "RP1":
        k = 1.2
        R = 287.0
    elif fuel_type == "LH2":
        k = 1.4
        R = 4124.0
    elif fuel_type == "SRF":
        k = 1.2
        R = 191.0
    elif fuel_type == "N2O4":
        k = 1.26
        R = 320.0
    else:
        return {"error": "Invalid fuel type"}

    ve = math.sqrt((2 * k) / (k - 1) * R * ct * (1 - (ap / cocp) ** ((k - 1) / k)))
    current_mass = intmass
    time_elapsed = 0.0

    time_steps = []
    thrust_values = []
    fuel_remaining = []
    mass_flow_values = []
    velocity_values = []

    while propmass > 0:
        thrust = mfr * ve
        mass_used = mfr * dt

        if mass_used > propmass:
            mass_used = propmass

        propmass -= mass_used
        current_mass -= mass_used

        time_steps.append(time_elapsed)
        thrust_values.append(thrust)
        fuel_remaining.append(propmass)
        mass_flow_values.append(mfr)
        velocity_values.append(ve)

        time_elapsed += dt

    return {
        "time": time_steps,
        "thrust": thrust_values,
        "fuel_remaining": fuel_remaining,
        "mass_flow": mass_flow_values,
        "velocity": velocity_values,
        "final_time": time_elapsed,
        "initial_thrust": thrust_values[0] if thrust_values else 0
    }


def nozzle_performance(mfr, ve, expa, amp, ea):

    thrust = (mfr * ve) + ((expa - amp) * ea)
    isp = thrust / (mfr * 9.81)

    return {
        "thrust": thrust,
        "isp": isp,
        "pressure_thrust": (expa - amp) * ea,
        "momentum_thrust": mfr * ve
    }


def main():
    print("Welcome to FlarePie! - Open Source Rocket Engine Simulator -")
    print("For Rocket Engine Simulator, type 1. For Nozzle Performance Calculator, type 2.")
    inp = int(input())

    if inp == 1:
        fuel_type = input("Fuel Type (RP1, LH2, SRF): ")
        cocp = float(input("Combustion Chamber Pressure (Pa): "))
        ct = float(input("Combustion Temperature (K): "))
        ap = float(input("Atmospheric Pressure (Pa): "))
        intmass = float(input("Total Mass, including Propellant (Kg): "))
        propmass = float(input("Propellant Mass (Kg): "))
        mfr = float(input("Mass Flow Rate (Kg/s): "))
        dt = float(input("Simulation Timestep (s): "))

        rocket_simulation(fuel_type, cocp, ct, ap, intmass, propmass, mfr, dt)
    elif inp == 2:
        mfr = float(input("Mass Flow Rate (Kg/s): "))
        ve = float(input("Exhaust Velocity (m/s): "))
        expa = float(input("Exit Pressure (Pa): "))
        amp = float(input("Ambient Pressure (Pa): "))
        ea = float(input("Exit Area (m^2): "))

        nozzle_performance(mfr, ve, expa, amp, ea)


if __name__ == "__main__":
    main()